import React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import Home from './components/Home';
import About from './components/About';
import Contact from './components/kontak';

const Stack = createNativeStackNavigator();

function MyContacts({ navigation }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>My Contact</Text>
      <Contact 
        gambar={require('./assets/mark.jpg')}
        judul="Mark Zuckerberg"
        telpon="0765535531"
        alamatEmail="mark@example.com"
        alamat="Jl. Jendral Sudirman No. 123, Jakarta"
        navigation={navigation}
      />
      <Contact 
        gambar={require('./assets/gates.jpg')}
        judul="Bill Gates"
        telpon="07655355421" 
        alamatEmail="gates@example.com"
        alamat="Jl. Jendral Sudirman No. 123, Jakarta"
        navigation={navigation}
      />
      <Contact 
        gambar={require('./assets/lon.jpg')}
        judul="Elon Musk"
        telpon="07655355311" 
        alamatEmail="elonmusk@example.com"
        alamat="Jl. Jendral Sudirman No. 123, Jakarta"
        navigation={navigation}
      />
      <Contact 
        gambar={require('./assets/jef.jfif')}
        judul="Jeff Bezos"
        telpon="076553551131" 
        alamatEmail="Jeffbezos@example.com"
        alamat="Jl. soekarno No. 123, Jakarta"
        navigation={navigation}
      />
      <Contact 
        gambar={require('./assets/jer.jfif')}
        judul="Jerome Poline"
        telpon="07655351121" 
        alamatEmail="jeromepolin@example.com"
        alamat="Jl. kuning No. 123, Surabaya"
        navigation={navigation}
      />
      <Contact 
        gambar={require('./assets/maudy.jfif')}
        judul="Maudy Ayunda"
        telpon="07655351123" 
        alamatEmail="maudyayunda@example.com"
        alamat="Jl. biru No. 123, Jakarta"
        navigation={navigation}
      />
    </View>
  );
}

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={Home} />
        <Stack.Screen name="About" component={About} />
        <Stack.Screen name="MyContacts" component={MyContacts} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
});
