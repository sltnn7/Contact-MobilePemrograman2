import React from 'react';
import { View, Text, Image, StyleSheet, Button } from 'react-native';

const About = ({ route, navigation }) => {
  const { judul, telpon, gambar, alamatEmail, alamat } = route.params;

  return (
    <View style={styles.container}>
      <Text style={styles.detailInfo}>Detail Informasi</Text>
      <Image source={gambar} style={styles.image} />
      <Text style={styles.title}>{judul}</Text>
      <Text style={styles.phone}>{telpon}</Text>
      <Text style={styles.email}>{alamatEmail}</Text> 
      <Text style={styles.info}>{alamat}</Text>
      <Button title="Go Back" onPress={() => navigation.goBack()} />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  detailInfo: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,  // Add some margin for spacing
  },
  image: {
    width: 300,
    height: 300,
    borderRadius: 50,
    marginBottom: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  phone: {
    fontSize: 18,
    color: 'gray',
  },
  email: {
    fontSize: 16,
    color: 'gray',
    marginBottom: 10,
  },
  info: {
    fontSize: 16,
    color: 'gray',
  },
});

export default About;
