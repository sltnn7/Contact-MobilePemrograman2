import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity } from 'react-native';

const Contact = ({ gambar, judul, telpon, alamatEmail, alamat, navigation }) => {
  return (
    <TouchableOpacity 
      style={styles.contactContainer}
      onPress={() => navigation.navigate('About', { judul, telpon, gambar, alamatEmail, alamat })}
    >
      <View style={styles.container}>
        <Image source={gambar} style={styles.image} />
        <View style={styles.textContainer}>
          <Text style={styles.contactName}>{judul}</Text>
        </View>
        <TouchableOpacity
          style={styles.viewButton}
          onPress={() => navigation.navigate('About', { judul, telpon, gambar, alamatEmail, alamat })}
        >
          <Text style={styles.viewText}>View</Text>
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  contactContainer: {
    padding: 10,
    marginVertical: 5,
    backgroundColor: '#fff',
    borderRadius: 5,
    elevation: 2,
  },
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  image: {
    width: 50,
    height: 50,
    borderRadius: 25,
    marginRight: 10,
  },
  textContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  contactName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 'auto', // Menggeser nama kontak ke kiri sejauh mungkin
  },
  viewButton: {
    backgroundColor: 'blue',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 5,
    marginLeft: 10,
  },
  viewText: {
    color: '#fff',
    fontWeight: 'bold',
  },
});

export default Contact;
